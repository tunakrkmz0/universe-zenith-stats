ALTER TABLE "Player"
ADD COLUMN "profileIconId" INTEGER;
